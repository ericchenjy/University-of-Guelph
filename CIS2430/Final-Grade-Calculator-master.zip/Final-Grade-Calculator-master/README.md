## Author Information

* Name: Junyan Chen
* Email: jchen52@uoguelph.ca
* Student ID: 1026737



## How to operate your program

	
### Running from the command line (without maven)

	-First, we open the command line, then we cd into the finalexam folder, then cd into the adventure folder where all the .java files are.
	-Then we type "javac main.java" to compile
	-Then we type "java main" to execute the program 


### Instructions for using the program
	
	-First, we open the command line, then we cd into the finalexam folder
	-Then type the " mvn compile " to compile
	-Then type the " mvn exec:java " to run the program
	
	-After running the program, it will print:

		Foo Bar 85.05
		Lorem Ipsum 83.16
		Generic Student 68.64

	
## Statement of Individual Work

By the action of submitting this work for grading, I certify that this assignment is my own work, based on my personal study.  I also certify that no parts of this assignment have previously been submitted for assessment in any other course, except where specific permission has been granted.  Finally, I certify that I have not copied in part or whole  or otherwise plagiarised the work of other persons.






