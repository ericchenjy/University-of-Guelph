package gradecalc;

public interface ResearchSubject {
    
    public void setParticipating(boolean isParticipating);
    public double researchPerk();  //returns the bonus grade

}
